import { Component } from '@angular/core';

@Component({
  selector: 'app-home-layout',
  template: `
    <app-dashboard></app-dashboard>

  `,
  styles: []
})
export class HomeLayoutComponent {}
