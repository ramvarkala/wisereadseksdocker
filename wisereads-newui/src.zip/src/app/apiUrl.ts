export class AppSettings {
      public static URL = 'http://13.127.158.42/';
}
